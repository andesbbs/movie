package com.movieticket.Movie.user;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
@RequestMapping("/user")
public class UserController {
	
	
	@RequestMapping(method = RequestMethod.POST,value = "/")
	public String verifyUser(Model model, @ModelAttribute User user) {	
		model.addAttribute("user", user);
		if(!user.getUsername().equals(user.getPassword())) {
		return "redirect:/error/";
		}
		return "redirect:/movies/";
		
	}

}
