package com.movieticket.Movie.ticket;

public class TicketController {

}
