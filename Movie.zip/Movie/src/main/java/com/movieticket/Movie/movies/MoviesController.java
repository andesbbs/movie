package com.movieticket.Movie.movies;

import java.util.ArrayList;
import java.util.List;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RestController;

@RestController("/movies")
public class MoviesController {
	
	
	@GetMapping
	public String getMovies(Model model) {
		
		List<Movie> movies=new ArrayList<>();
		Movie movie1=new Movie();
		movie1.setName("avangers");
		movie1.setId(1);
		Movie movie2=new Movie();
		movie2.setName("Pirates of carribian");
		movie2.setId(2);
		movies.add(movie1);
		movies.add(movie2);
		model.addAttribute("movies",movies);
		return "movies";
	}

}
